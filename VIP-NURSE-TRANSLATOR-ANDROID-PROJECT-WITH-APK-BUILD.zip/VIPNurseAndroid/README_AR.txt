VIP NURSE TRANSLATOR — Android + Google ML Kit

المشروع ده بيحوّل نسخة HTML إلى تطبيق Android WebView، ويضيف Google ML Kit Text Recognition للنصوص اللاتينية/الإنجليزية. لو ML Kit لم يرجع نتيجة كافية، التطبيق يرجع تلقائياً إلى Tesseract الموجود داخل HTML.

التشغيل:
1) نزّل Android Studio وثبّته على الكمبيوتر.
2) فك ضغط VIP-NURSE-TRANSLATOR-ANDROID-PROJECT.zip.
3) من Android Studio اختر Open وافتح مجلد VIPNurseAndroid.
4) وافق على تثبيت Android SDK 35 وأي مكونات Gradle يطلبها Android Studio.
5) انتظر Gradle Sync حتى ينتهي.
6) وصّل هاتف Android مع تفعيل Developer options وUSB debugging، أو شغّل Emulator.
7) اضغط Run لتثبيت التطبيق وتشغيله.

أول تشغيل:
- يحتاج اتصال إنترنت لتنزيل نموذج ML Kit من Google Play services (لأننا استخدمنا نسخة unbundled لتقليل حجم التطبيق).
- بعد تنزيل النموذج، OCR يعمل على الجهاز للنصوص اللاتينية. عند تعذر ML Kit يرجع التطبيق إلى Tesseract.
- ملفات PDF والصور تختارها من زر رفع الملف داخل التطبيق.

ملاحظات مهمة:
- ده مشروع Android Studio جاهز للبناء، وليس APK جاهزاً للتثبيت. لا يمكن إنتاج APK موقّع/مختبر من هنا دون بيئة Android SDK/Gradle وبناء فعلي.
- ML Kit المستخدم هنا مخصص للنصوص اللاتينية، لذلك عند اختيار العربية كمصدر يتجاوز ML Kit ويستخدم Tesseract.
- لا يوجد OCR يضمن قراءة كل كلمة أو جدول طبي بلا أخطاء؛ راجع النص المستخرج قبل الاعتماد الطبي أو الدراسي.
- ملف HTML الأصلي محفوظ داخل app/src/main/assets/index.html، ويمكن فتحه منفرداً في متصفح عادي؛ في المتصفح سيستخدم Tesseract كخطة بديلة ولا يتوفر ML Kit.

طريقة استخراج APK بدون تثبيت Android Studio:
1) أنشئ مستودعاً جديداً على GitHub وارفع محتويات المجلد VIPNurseAndroid إليه (بما فيها مجلد .github).
2) افتح تبويب Actions في المستودع.
3) اختر Build VIP Nurse Translator APK ثم Run workflow.
4) بعد انتهاء البناء بنجاح، افتح نتيجة التشغيل وانزل إلى Artifacts.
5) نزّل VIP-NURSE-TRANSLATOR-debug-apk وفك ضغطه؛ ستجد app-debug.apk.
6) انقل APK إلى هاتف Android وثبّته. قد يطلب الهاتف السماح بالتثبيت من هذا المصدر.

هذا المسار يبني APK تجريبياً (debug) غير مخصص للنشر على Google Play. يتطلب حساب GitHub واتصال إنترنت أثناء البناء. لم يتم تنفيذ البناء هنا لأن بيئة العمل الحالية لا تحتوي Android SDK أو Gradle.
