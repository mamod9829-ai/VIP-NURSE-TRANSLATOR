package com.vipnurse.translator;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Intent;
import android.net.Uri;
import android.util.Base64;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView web;
    private TextRecognizer recognizer;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private static final int FILE_PICKER = 4102;
    private ValueCallback<Uri[]> fileCallback;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent i = params.createIntent();
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/pdf", "image/*", "text/plain", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"});
                try { startActivityForResult(i, FILE_PICKER); return true; }
                catch (Exception e) { fileCallback = null; Toast.makeText(MainActivity.this, "تعذر فتح الملفات", Toast.LENGTH_SHORT).show(); return false; }
            }
        });
        web.addJavascriptInterface(new MLKitBridge(), "AndroidMLKit");
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        web.loadUrl("file:///android_asset/index.html");
    }

    private class MLKitBridge {
        @JavascriptInterface public void recognize(String dataUrl, String callbackId) {
            executor.execute(() -> {
                String result = "[]";
                try {
                    int comma = dataUrl.indexOf(',');
                    if (comma < 0) throw new IllegalArgumentException("Invalid image data");
                    byte[] bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    if (bitmap == null) throw new IllegalArgumentException("Image decode failed");
                    InputImage image = InputImage.fromBitmap(bitmap, 0);
                    Text text = com.google.android.gms.tasks.Tasks.await(recognizer.process(image));
                    JSONArray rows = new JSONArray();
                    for (Text.TextBlock block : text.getTextBlocks()) {
                        for (Text.Line line : block.getLines()) {
                            Rect r = line.getBoundingBox();
                            if (r == null || line.getText().trim().isEmpty()) continue;
                            JSONObject row = new JSONObject();
                            row.put("t", line.getText().replaceAll("\\\\s+", " ").trim());
                            row.put("x0", r.left); row.put("y0", r.top);
                            row.put("x1", r.right); row.put("y1", r.bottom);
                            row.put("h", Math.max(1, r.height())); row.put("c", 0.90);
                            row.put("words", new JSONArray()); row.put("cells", new JSONArray());
                            rows.put(row);
                        }
                    }
                    result = rows.toString();
                    bitmap.recycle();
                } catch (Exception e) { android.util.Log.e("VIPNurse", "ML Kit OCR failed", e); }
                final String payload = result;
                runOnUiThread(() -> {
                    if (web != null) web.evaluateJavascript("window.__mlkitDone(" + JSONObject.quote(callbackId) + "," + JSONObject.quote(payload) + ")", null);
                });
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_PICKER && fileCallback != null) {
            Uri[] result = (resultCode == RESULT_OK && data != null && data.getData() != null) ? new Uri[]{data.getData()} : null;
            fileCallback.onReceiveValue(result); fileCallback = null;
        }
    }
    @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { if (recognizer != null) recognizer.close(); executor.shutdown(); if (web != null) web.destroy(); super.onDestroy(); }
}
